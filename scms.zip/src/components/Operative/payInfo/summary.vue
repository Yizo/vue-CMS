<template>
  <div class="smy">
    <div class="smy1">
      <div class="warp">
        <el-card class="box-card">
          <div slot="header" class="clearfix">
            <span><充值金额></充值金额>汇总</span>
          </div>
          <div class="text item">
            <p>
              {{s_data.total_recharge_amount_today}}/{{s_data.total_recharge_amount_month}}/{{s_data.total_recharge_amount_year}}</p>
            <p>今日充值金额/本月充值金额/本年充值金额</p>
          </div>
        </el-card>
      </div>
      <div class="warp">
        <el-card class="box-card">
          <div slot="header" class="clearfix">
            <span>充值人数汇总</span>
          </div>
          <div class="text item">
            <p>
              {{s_data.total_recharge_users_count_today}}/{{s_data.total_recharge_users_count_month}}/{{s_data.total_recharge_users_count_year
              }}</p>
            <p>今日充值总人数/本月充值总人数/本年充值总人数</p>
          </div>
        </el-card>
      </div>
      <div class="warp">
        <el-card class="box-card">
          <div slot="header" class="clearfix">
            <span>消费汇总</span>
          </div>
          <div class="text item">
            <p>
              {{s_data.total_consume_coins_today}}/{{s_data.total_consume_coins_month}}/{{s_data.total_consume_coins_year}}</p>
            <p>今日消费钻石/本月消费钻石/本年消费钻石</p>
          </div>
        </el-card>
      </div>
      <div class="warp">
        <el-card class="box-card">
          <div slot="header" class="clearfix">
            <span>ARUP值</span>
          </div>
          <div class="text item">
            <p style="padding: 8px 0;">{{s_data.total_recharge_amount_month/s_data.total_recharge_users_count_month |
              zero | format_number}}(元)</p>
          </div>
        </el-card>
      </div>
    </div>
    <pay-info></pay-info>
    <div class="smy2">
      <div id="main" style="height: 500px;">

      </div>
    </div>
  </div>
</template>

<script>
  import {mapActions, mapGetters}  from 'vuex'
  import * as JS from '../../../assets/js/js'
  import payInfo from './payInfo.vue'
  export default {
    components:{
      payInfo
    },
    data(){
      return {

        /*折线图*/
        options: {
          title: {
            text: null
          },
          xAxis: {
            categories: []
          },
          yAxis: {
            title: {
              text: null
            },
            plotLines: [{
              value: 0,
              width: 1,
              color: '#808080'
            }]
          },
          tooltip: {
            valueSuffix: null
          },
          series: [],
          credits: false
        },
      }
    },
    computed: {
      ...mapGetters({
        s_data: 'summary_data',
        pdData:'pay_details_data',
        time: 'time'
      })
    },
    methods: {
      AnalysisJSON(parm) {
        var result = []
        var keyList = {total_recharge_amount: '充值金额总数', total_consume_coins: '消费钻石总数', recharge_users_count: '充值总人数'}
        var names = ['total_recharge_amount', 'total_consume_coins', 'recharge_users_count']
        for (var i = 0; i < names.length; i++) {
          var data = []
          for (var j = 0; j < parm.length; j++) {
            data.push(parseInt(parm[j][names[i]]))
          }
          var item = {name: keyList[names[i]], data: data}
          result.push(item)
        }
        return result
      },
      //设置Y轴
      setXAxis(parm){
        var arry = []
        for (var i in parm) {
          arry.push(parm[i].stat_date);
        }
        return arry
      },
    },
    watch:{
      pdData:function(newData){
        this.options.series = [...this.AnalysisJSON(newData.data.logs)]
        this.options.xAxis.categories = [...this.setXAxis(newData.data.logs)]
        this.$HighCharts.chart('main',this.options)
      },
    },
    mounted(){
      this.$store.dispatch('PAYINFO_consume_coins_details').then(() => {
        this.$store.dispatch('PAYINFO_pay_details', {
          year: this.time.year || null,
          month: this.time.month || null
        }).then(res=>{
          this.options.series = [...this.AnalysisJSON(res.data.data.logs)]
          this.options.xAxis.categories = [...this.setXAxis(res.data.data.logs)]
          this.$HighCharts.chart('main',this.options)
        });
      });
    }
  }
</script>

<style scoped>
  .smy1, .smy2 {
    text-align: left;
    display: flex;
    align-items: center;
    justify-content: flex-start;
    margin-top: 20px;
  }

  .smy2 {
    padding: 10px;
    background-color: #fff;
  }

  .warp {
    flex: 0 0 25%;
  }

  .box-card {
    width: calc(100% - 10px);
  }

  .smy2 > div {
    width: calc(100% - 10px);
  }
</style>

