<template>
  <div class="warp">
    <p class="header"><span>充值详情</span></p>
    <el-table
      :data="pd_data.data.logs"
      style="width: 100%">
      <el-table-column
        prop="stat_date"
        label="日期"
        width="180">
      </el-table-column>
      <el-table-column
        label="充值金额">
        <template scope="scope">
          <span class="tip" @click="recharge_amount('充值金额')">{{scope.row.total_recharge_amount}}</span>
        </template>
      </el-table-column>
      <el-table-column
        label="消费钻石">
        <template scope="scope">
          <span class="tip" @click="consume">{{scope.row.total_consume_coins}}</span>
        </template>
      </el-table-column>
      <el-table-column
        label="充值人数">
        <template scope="scope">
          <span class="tip" @click="recharge_users('充值人数')">{{scope.row.recharge_users_count}}</span>
        </template>
      </el-table-column>
    </el-table>
    <!--分页-->
    <el-pagination
      @current-change="handleCurrentChange"
      :current-page="pd_data.data.current_page"
      layout="total, prev, pager, next, jumper"
      :total="pd_data.data.total_count"
      :page-size="pageSize"
      class="page">
    </el-pagination>
    <!--充值金额/充值人数-->
    <el-dialog v-model="dialogVisible" :title="title">
      <el-table :data="dalogInfo.data" style="text-align: center">
        <el-table-column property="username" label="账号名" width="150"></el-table-column>
        <el-table-column property="coins" label="充值金额">
          <template scope="scope">
            <span>1</span>
          </template>
        </el-table-column>
        <el-table-column label="充值时间点" width="150">
          <template scope="scope">
            {{Timestamp(scope.row.created_at)}}
          </template>
        </el-table-column>
      </el-table>
      <div slot="footer">
        <!--        <el-pagination
                  @current-change="handleCurrentChange_sn"
                  :current-page="currentPage"
                  :page-size="10"
                  :total="total"
                  layout="prev,next"
                  class="page">
                </el-pagination>-->
      </div>
    </el-dialog>
    <!--消费钻石-->
    <el-dialog v-model="dialogVisible2" title="消费钻石">
      <el-table :data="dalogInfo2" style="text-align: center">
        <el-table-column property="username" label="账号名" width="150"></el-table-column>
        <el-table-column property="coins" label="使用服务器名">
          <template scope="scope">
            {{scope.row.node_type+"-"+scope.row.node_region+"-"+scope.row.node_name}}
          </template>
        </el-table-column>
        <el-table-column property="coins" label="消费钻石数量" width="150"></el-table-column>
        <el-table-column label="扣除钻石时间点" width="150">
          <template scope="scope">
            {{Timestamp(scope.row.created_at)}}
          </template>
        </el-table-column>
      </el-table>
      <div slot="footer">
        <!--        <el-pagination
                  @current-change="handleCurrentChange_sn"
                  :current-page="currentPage"
                  :page-size="10"
                  :total="total"
                  layout="prev,next"
                  class="page">
                </el-pagination>-->
      </div>
    </el-dialog>
  </div>
</template>

<script>
  import { mapActions,mapGetters }  from 'vuex'
  import * as JS from '../../../assets/js/js'
  import * as API from '../../../api/api'
  export default {
    data(){
      return {
        dialogVisible:false,
        dialogVisible2:false,
        pay_details_data:{
            data:{
                log:{

                }
            }
        },
        title:'',
        dalogInfo:{
           name:'',
           data:[]
        },
        dalogInfo2:[],
        pageSize:15
      }
    },
    computed:{
      ...mapGetters({
        pd_data:'pay_details_data'
      })
    },
    methods:{
      //充值人数详情
      tccd(parm){
        return  new Promise( (resolve,reject) => {
          const token = JSON.parse(window.sessionStorage.getItem('loginInfo')).token;
          this.$http({
            method:'GET',
            url:API.t_consume_coins_details,
            headers: {'Authorization': token},
            params:parm
          }).then(function(res){
            if(res.status == 200){
              resolve(res)
            }
          }).catch(function(err){
            reject(err)
          })
        })
      },
      //充值金额详情
      trad(parm){
        return  new Promise( (resolve,reject) => {
          const token = JSON.parse(window.sessionStorage.getItem('loginInfo')).token;
          this.$http({
            method:'GET',
            url:API.t_recharge_amount_details,
            headers: {'Authorization': token},
            params:parm
          }).then(function(res){
            if(res.status == 200){
              resolve(res)
            }
          }).catch(function(err){
            reject(err)
          })
        })
      },
      recharge_amount(data){
        this.dialogVisible = true;
        console.log(data)
        this.title=data
        this.tccd().then(res=>{
          this.dalogInfo.data = res.data.data.logs

        })
      },
      consume(){
        this.dialogVisible2 = true;
        this.tccd().then(res=>{
          this.dalogInfo2 = res.data.data.logs
        })
      },
      recharge_users(data){
        this.dialogVisible = true;
        this.title=data
        this.tccd().then(res=>{
          this.dalogInfo.data = res.data.data.logs
        })
      },
      Timestamp(row){
        const now = new Date(row*1000);
        var year=now.getFullYear();
        var month=now.getMonth()+1;
        var date=now.getDate();

        if(month<9){
          month = '0'+month
        }
        if(date<9){
          date = '0'+date
        }

        return year+"-"+month+"-"+date;
      },
      handleCurrentChange(){

      }
    },
    mounted(){
      this.$store.dispatch('PAYINFO_pay_details');
    }
  }
</script>

<style scoped>
  .warp{
    padding: 10px;
    text-align: left;
    padding: 10px;
    background-color:#fff;
    border:1px solid #f5f5f5;
    box-shadow: 0 0 2px 1px #ddd;
    margin-top: 20px;
  }
  .header{
    height: 40px;
    line-height: 40px;
    font-size: 16px;
    border-bottom: transparent;
  }
  .header span{
    display: block;
    width: 20%;
    margin-left: 10px;
  }
  .tip{
    cursor: pointer;
    background-color: #333;
    padding: 1px 3px;
    color: #fff
  }
  .page{
    text-align: right;
    margin-top: 20px;
  }
</style>
