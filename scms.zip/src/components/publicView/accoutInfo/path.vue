<template>
  <div>
    <div class="block" style="text-align: left;margin-bottom: 10px">
      <el-date-picker
        v-model="time"
        type="date"
        placeholder="选择日期">
      </el-date-picker>
      <el-button type="primary" icon="search" style="margin-left: 10px">筛选</el-button>
    </div>
    <el-table
      :data="data.logs"
      style="width: 100%">
      <el-table-column
        prop="times"
        label="开启次数">
      </el-table-column>
      <el-table-column
        prop="interface_id"
        label="操作步骤">
      </el-table-column>
      <el-table-column
        prop="interface_name"
        label="界面名">
      </el-table-column>

    </el-table>
    <el-pagination
      @current-change="handleCurrentChange"
      :current-page="data.current_page"
      :page-size="10"
      layout="prev, pager, next, jumper"
      style="margin-top: 10px">
    </el-pagination>
  </div>
</template>

<script>
  import * as API from '../../../api/api'
  import { mapGetters,mapActions } from 'vuex'
  export default {
    data(){
      return {
          time:''
      }
    },
    computed:{
      ...mapGetters({
        data:'UD_operation_logs'
      })
    },
    methods:{
      ...mapActions({
        UD_operation_logs: "UD_operation_logs",
      }),
      handleCurrentChange(val){
        var id = window.sessionStorage.getItem('userId')
        this.UD_operation_logs({id:id,page:val,limit:10}).then(res=>{

        })
      },
    },
    mounted(){

    }
  }
</script>
