<template>
  <div>
    <p style="margin-bottom: 10px;text-align: left">使用总流量<span style="padding: 0 10px;color: red">{{data.total_bytes}}</span></p>
    <el-table
      :data="data.connection_logs"
      style="width: 100%">
      <el-table-column
        label="日期">
        <template scope="scope">
          {{scope.row.created_at | Time}}
        </template>
      </el-table-column>
      <el-table-column
        prop="ip"
        label="用户IP">
      </el-table-column>
      <el-table-column
        prop="node_name"
        label="线路">
        <template scope="scope">
          {{scope.row.node_type_name}}_{{scope.row.node_region_name}}_{{scope.row.node_name}}
        </template>
      </el-table-column>
      <el-table-column
        prop="wait_time"
        label="时长(单位:秒)">
      </el-table-column>
    </el-table>

    <el-pagination
      @current-change="handleCurrentChange"
      :current-page="data.current_page"
      :page-size="10"
      layout="prev, pager, next, jumper"
      style="margin-top: 10px">
    </el-pagination>
  </div>
</template>

<script>
  import * as API from '../../../api/api'
  import { mapGetters,mapActions } from 'vuex'
  export default {
    data(){
        return {

        }
    },
    computed:{
      ...mapGetters({
        data:'UD_base_info'
      }),
    },
    watch:{

    },
    methods:{
      ...mapActions({
        UD_base_info: "UD_base_info",
      }),
      handleCurrentChange(val){
        var id = window.sessionStorage.getItem('userId')
        this.UD_base_info({id:id,page:val,limit:10}).then(res=>{

        })
      },
    },
    mounted(){

    }

  }
</script>
