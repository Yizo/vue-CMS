<template>
  <div>
    <el-table
      :data="data.devices"
      style="width: 100%">
      <el-table-column
        prop="model"
        label="硬件型号">
      </el-table-column>
      <el-table-column
        prop="uuid"
        label="UUID">
      </el-table-column>
      <el-table-column
        prop="platform"
        label="平台">
      </el-table-column>
    </el-table>
    <el-pagination
      @current-change="handleCurrentChange"
      :current-page="data.current_page"
      :page-size="10"
      layout="prev, pager, next, jumper"
      style="margin-top: 10px">
    </el-pagination>
  </div>
</template>

<script>
  import * as API from '../../../api/api'
  import { mapGetters,mapActions } from 'vuex'
  export default {
    data(){
      return {

      }
    },
    methods:{
      ...mapActions({
        devices: "UD_devices",
      }),
      handleCurrentChange(val){
        var id = window.sessionStorage.getItem('userId')
        this.devices({id:id,page:val,limit:10})
      },
    },
    computed:{
      ...mapGetters({
        data:'UD_devices'
      })
    },
    mounted(){

    }
  }
</script>
