<template>
  <div id="content">

  </div>
</template>

<script>

</script>

<style lang="less" scoped>
#content{
  width: 100%;
  height: 500px;
  background: rgba(0,0,0,0.1);
}
</style>
