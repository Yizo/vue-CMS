<template>
  <div id="index">
    <el-row class="main">
      <navs class="nav"></navs>
      <div class="content" style="width: calc(100% - 180px)">
        <router-view></router-view>
      </div>
    </el-row>
  </div>
</template>

<script>

  import navs from '../publicView/nav.vue'
  export default {
    components:{
      navs
    },
    mounted(){
      (function(w){
        const h = w.document.documentElement.getBoundingClientRect().height;
        document.getElementById("index").style.height = h + 'px';
      })(window)
    }
  }
</script>

<style lang="less" scoped>
  #index .main{
    display: flex;
  }
  .nav{
    width: 180px;
  }
  .content{
    width: calc(100% - 180px);
    overflow: hidden;
    background-color: #f3f3f3;
  }
</style>

