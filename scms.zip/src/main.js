import Vue from 'vue'
import App from './App'
import router from './router'
import store from './store'
import axios from 'axios'
import HighCharts from 'highcharts'
import ElementUI from 'element-ui'
import 'element-ui/lib/theme-default/index.css'
import './assets/css/reset.css'
import * as filters from './filter/filter'
Vue.prototype.$http = axios;
Vue.prototype.$HighCharts = HighCharts;

Vue.use(ElementUI)
Vue.use(router)
Vue.config.productionTip = false

for(var key in filters){
  Vue.filter(key,filters[key])
}

new Vue({
  el: '#app',
  router,
  store,
  render: h => h(App)
})

