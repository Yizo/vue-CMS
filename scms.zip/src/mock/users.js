/**
 * Created by admin on 2017/4/8.
 */
const users = [
  {
    "id": 336,
    "username": "sup00000336",
    "uuid": "a4964ec7-025b-34c1-ac79-2cefdb3479e4",
    "is_enabled": true,
    "total_payment_amount": "0.0",
    "current_coins": 0,
    "total_coins": 0,
    "group_name": "vip0",
    "group_id": 1,
    "last_app_launched_at": 1491639283,
    "last_app_launched_version": "123123_1.0alph_1.0",
    "created_at": 1491639283,
    "created_version": "123123_1.0_1.0",
    "user_node_types": [
      {
        "id": 1676,
        "name": "青铜服",
        "level": 1,
        "status": "按次",
        "expired_at": 1491639283,
        "used_count": 0
      },
      {
        "id": 1677,
        "name": "白银服",
        "level": 2,
        "status": "按次",
        "expired_at": 1491639283,
        "used_count": 0
      },
      {
        "id": 1678,
        "name": "黄金服",
        "level": 3,
        "status": "按次",
        "expired_at": 1491639283,
        "used_count": 0
      },
      {
        "id": 1679,
        "name": "铂金服",
        "level": 4,
        "status": "按次",
        "expired_at": 1491639283,
        "used_count": 0
      },
      {
        "id": 1680,
        "name": "钻石服",
        "level": 5,
        "status": "按次",
        "expired_at": 1491639283,
        "used_count": 0
      }
    ]
  },
  {
    "id": 335,
    "username": "sup00000335",
    "uuid": "BC4791FB-CD6B-4FE0-A29B-31A385C9FA2E",
    "is_enabled": true,
    "total_payment_amount": "9999.0",
    "current_coins": 9998,
    "total_coins": 0,
    "group_name": "VIP10",
    "group_id": 11,
    "last_app_launched_at": "",
    "last_app_launched_version": "",
    "created_at": 1491637707,
    "created_version": "appStore_AppStore_jichu_1.0",
    "user_node_types": [
      {
        "id": 1671,
        "name": "青铜服",
        "level": 1,
        "status": "按次",
        "expired_at": 1491724365,
        "used_count": 1
      },
      {
        "id": 1672,
        "name": "白银服",
        "level": 2,
        "status": "按次",
        "expired_at": 1491637707,
        "used_count": 0
      },
      {
        "id": 1673,
        "name": "黄金服",
        "level": 3,
        "status": "按次",
        "expired_at": 1491637707,
        "used_count": 0
      },
      {
        "id": 1674,
        "name": "铂金服",
        "level": 4,
        "status": "按次",
        "expired_at": 1491637707,
        "used_count": 0
      },
      {
        "id": 1675,
        "name": "钻石服",
        "level": 5,
        "status": "按次",
        "expired_at": 1491637707,
        "used_count": 0
      }
    ]
  },
  {
    "id": 334,
    "username": "sup00000334",
    "uuid": "BC4791FB-CD6B-4FE0-A29B-31A385C9FA2E",
    "is_enabled": true,
    "total_payment_amount": "0.0",
    "current_coins": 0,
    "total_coins": 0,
    "group_name": "vip0",
    "group_id": 1,
    "last_app_launched_at": "",
    "last_app_launched_version": "",
    "created_at": 1491637646,
    "created_version": "appStore_AppStore_jichu_1.0",
    "user_node_types": [
      {
        "id": 1666,
        "name": "青铜服",
        "level": 1,
        "status": "按次",
        "expired_at": 1491637646,
        "used_count": 0
      },
      {
        "id": 1667,
        "name": "白银服",
        "level": 2,
        "status": "按次",
        "expired_at": 1491637647,
        "used_count": 0
      },
      {
        "id": 1668,
        "name": "黄金服",
        "level": 3,
        "status": "按次",
        "expired_at": 1491637647,
        "used_count": 0
      },
      {
        "id": 1669,
        "name": "铂金服",
        "level": 4,
        "status": "按次",
        "expired_at": 1491637647,
        "used_count": 0
      },
      {
        "id": 1670,
        "name": "钻石服",
        "level": 5,
        "status": "按次",
        "expired_at": 1491637647,
        "used_count": 0
      }
    ]
  },
  {
    "id": 333,
    "username": "sup00000333",
    "uuid": "BC4791FB-CD6B-4FE0-A29B-31A385C9FA2E",
    "is_enabled": true,
    "total_payment_amount": "9999.0",
    "current_coins": 9999,
    "total_coins": 0,
    "group_name": "VIP10",
    "group_id": 11,
    "last_app_launched_at": "",
    "last_app_launched_version": "",
    "created_at": 1491637560,
    "created_version": "appStore_AppStore_jichu_1.0",
    "user_node_types": [
      {
        "id": 1661,
        "name": "青铜服",
        "level": 1,
        "status": "按次",
        "expired_at": 1491637560,
        "used_count": 0
      },
      {
        "id": 1662,
        "name": "白银服",
        "level": 2,
        "status": "按次",
        "expired_at": 1491637560,
        "used_count": 0
      },
      {
        "id": 1663,
        "name": "黄金服",
        "level": 3,
        "status": "按次",
        "expired_at": 1491637560,
        "used_count": 0
      },
      {
        "id": 1664,
        "name": "铂金服",
        "level": 4,
        "status": "按次",
        "expired_at": 1491637560,
        "used_count": 0
      },
      {
        "id": 1665,
        "name": "钻石服",
        "level": 5,
        "status": "按次",
        "expired_at": 1491637560,
        "used_count": 0
      }
    ]
  },
  {
    "id": 331,
    "username": "sup00000331",
    "uuid": "90e398e8-d97b-38cd-b9dd-ee17c6c6a543",
    "is_enabled": true,
    "total_payment_amount": "0.0",
    "current_coins": 0,
    "total_coins": 0,
    "group_name": "vip0",
    "group_id": 1,
    "last_app_launched_at": 1491637287,
    "last_app_launched_version": "123123_1.0_1.0",
    "created_at": 1491637287,
    "created_version": "123123_1.0_1.0",
    "user_node_types": [
      {
        "id": 1651,
        "name": "青铜服",
        "level": 1,
        "status": "按次",
        "expired_at": 1491637287,
        "used_count": 0
      },
      {
        "id": 1652,
        "name": "白银服",
        "level": 2,
        "status": "按次",
        "expired_at": 1491637287,
        "used_count": 0
      },
      {
        "id": 1653,
        "name": "黄金服",
        "level": 3,
        "status": "按次",
        "expired_at": 1491637287,
        "used_count": 0
      },
      {
        "id": 1654,
        "name": "铂金服",
        "level": 4,
        "status": "按次",
        "expired_at": 1491637287,
        "used_count": 0
      },
      {
        "id": 1655,
        "name": "钻石服",
        "level": 5,
        "status": "按次",
        "expired_at": 1491637287,
        "used_count": 0
      }
    ]
  },
  {
    "id": 332,
    "username": "sup00000332",
    "uuid": "90e398e8-d97b-38cd-b9dd-ee17c6c6a543",
    "is_enabled": true,
    "total_payment_amount": "0.0",
    "current_coins": 0,
    "total_coins": 0,
    "group_name": "vip0",
    "group_id": 1,
    "last_app_launched_at": 1491637287,
    "last_app_launched_version": "123123_1.0_1.0",
    "created_at": 1491637287,
    "created_version": "123123_1.0_1.0",
    "user_node_types": [
      {
        "id": 1656,
        "name": "青铜服",
        "level": 1,
        "status": "按次",
        "expired_at": 1491637287,
        "used_count": 0
      },
      {
        "id": 1657,
        "name": "白银服",
        "level": 2,
        "status": "按次",
        "expired_at": 1491637287,
        "used_count": 0
      },
      {
        "id": 1658,
        "name": "黄金服",
        "level": 3,
        "status": "按次",
        "expired_at": 1491637287,
        "used_count": 0
      },
      {
        "id": 1659,
        "name": "铂金服",
        "level": 4,
        "status": "按次",
        "expired_at": 1491637287,
        "used_count": 0
      },
      {
        "id": 1660,
        "name": "钻石服",
        "level": 5,
        "status": "按次",
        "expired_at": 1491637287,
        "used_count": 0
      }
    ]
  },
  {
    "id": 330,
    "username": "sup00000330",
    "uuid": "a1de3867-7468-4002-8dd4-554707c4edc5",
    "is_enabled": true,
    "total_payment_amount": "0.0",
    "current_coins": 0,
    "total_coins": 0,
    "group_name": "vip0",
    "group_id": 1,
    "last_app_launched_at": 1491637248,
    "last_app_launched_version": "ac654e5a-0895-11e7-8c9d-784f4352f7e7_ac692b38-0895-11e7-8c9d-784f4352f7e7_0.2",
    "created_at": 1491637247,
    "created_version": "ac654e5a-0895-11e7-8c9d-784f4352f7e7_ac692b38-0895-11e7-8c9d-784f4352f7e7_0.2",
    "user_node_types": [
      {
        "id": 1646,
        "name": "青铜服",
        "level": 1,
        "status": "按次",
        "expired_at": 1491637247,
        "used_count": 0
      },
      {
        "id": 1647,
        "name": "白银服",
        "level": 2,
        "status": "按次",
        "expired_at": 1491637247,
        "used_count": 0
      },
      {
        "id": 1648,
        "name": "黄金服",
        "level": 3,
        "status": "按次",
        "expired_at": 1491637248,
        "used_count": 0
      },
      {
        "id": 1649,
        "name": "铂金服",
        "level": 4,
        "status": "按次",
        "expired_at": 1491637248,
        "used_count": 0
      },
      {
        "id": 1650,
        "name": "钻石服",
        "level": 5,
        "status": "按次",
        "expired_at": 1491637248,
        "used_count": 0
      }
    ]
  },
  {
    "id": 329,
    "username": "sup00000329",
    "uuid": "BC4791FB-CD6B-4FE0-A29B-31A385C9FA2E",
    "is_enabled": true,
    "total_payment_amount": "0.0",
    "current_coins": 0,
    "total_coins": 0,
    "group_name": "vip0",
    "group_id": 1,
    "last_app_launched_at": "",
    "last_app_launched_version": "",
    "created_at": 1491637099,
    "created_version": "appStore_AppStore_jichu_1.0",
    "user_node_types": [
      {
        "id": 1641,
        "name": "青铜服",
        "level": 1,
        "status": "按次",
        "expired_at": 1491637099,
        "used_count": 0
      },
      {
        "id": 1642,
        "name": "白银服",
        "level": 2,
        "status": "按次",
        "expired_at": 1491637099,
        "used_count": 0
      },
      {
        "id": 1643,
        "name": "黄金服",
        "level": 3,
        "status": "按次",
        "expired_at": 1491637099,
        "used_count": 0
      },
      {
        "id": 1644,
        "name": "铂金服",
        "level": 4,
        "status": "按次",
        "expired_at": 1491637099,
        "used_count": 0
      },
      {
        "id": 1645,
        "name": "钻石服",
        "level": 5,
        "status": "按次",
        "expired_at": 1491637099,
        "used_count": 0
      }
    ]
  },
  {
    "id": 327,
    "username": "sup00000327",
    "uuid": "90e398e8-d97b-38cd-b9dd-ee17c6c6a543",
    "is_enabled": true,
    "total_payment_amount": "0.0",
    "current_coins": 0,
    "total_coins": 0,
    "group_name": "vip0",
    "group_id": 1,
    "last_app_launched_at": 1491637068,
    "last_app_launched_version": "123123_1.0_1.0",
    "created_at": 1491637068,
    "created_version": "123123_1.0_1.0",
    "user_node_types": [
      {
        "id": 1631,
        "name": "青铜服",
        "level": 1,
        "status": "按次",
        "expired_at": 1491637068,
        "used_count": 0
      },
      {
        "id": 1632,
        "name": "白银服",
        "level": 2,
        "status": "按次",
        "expired_at": 1491637068,
        "used_count": 0
      },
      {
        "id": 1633,
        "name": "黄金服",
        "level": 3,
        "status": "按次",
        "expired_at": 1491637068,
        "used_count": 0
      },
      {
        "id": 1634,
        "name": "铂金服",
        "level": 4,
        "status": "按次",
        "expired_at": 1491637068,
        "used_count": 0
      },
      {
        "id": 1636,
        "name": "钻石服",
        "level": 5,
        "status": "按次",
        "expired_at": 1491637068,
        "used_count": 0
      }
    ]
  },
  {
    "id": 328,
    "username": "sup00000328",
    "uuid": "90e398e8-d97b-38cd-b9dd-ee17c6c6a543",
    "is_enabled": true,
    "total_payment_amount": "0.0",
    "current_coins": 0,
    "total_coins": 0,
    "group_name": "vip0",
    "group_id": 1,
    "last_app_launched_at": 1491637068,
    "last_app_launched_version": "123123_1.0_1.0",
    "created_at": 1491637068,
    "created_version": "123123_1.0_1.0",
    "user_node_types": [
      {
        "id": 1635,
        "name": "青铜服",
        "level": 1,
        "status": "按次",
        "expired_at": 1491637068,
        "used_count": 0
      },
      {
        "id": 1637,
        "name": "白银服",
        "level": 2,
        "status": "按次",
        "expired_at": 1491637068,
        "used_count": 0
      },
      {
        "id": 1638,
        "name": "黄金服",
        "level": 3,
        "status": "按次",
        "expired_at": 1491637068,
        "used_count": 0
      },
      {
        "id": 1639,
        "name": "铂金服",
        "level": 4,
        "status": "按次",
        "expired_at": 1491637068,
        "used_count": 0
      },
      {
        "id": 1640,
        "name": "钻石服",
        "level": 5,
        "status": "按次",
        "expired_at": 1491637068,
        "used_count": 0
      }
    ]
  }
]

export default users
