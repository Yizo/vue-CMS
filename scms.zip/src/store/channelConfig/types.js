/**
 * Created by isec on 2017/4/14.
 */

// 获取列表
export const GET_CHANNEL_DATA = 'GET_CHANNEL_DATA';

//添加渠道
export const ADD_CHANNEL = 'ADD_CHANNEL';

//删除列表
export const DELETE_CHANNEL = 'DELETE_CHANNEL';

//更新列表
export const UPDATE_CHANNEL = 'UPDATE_CHANNEL';

//添加成功
export const ADD_SUCCESS = 'ADD_SUCCESS';
