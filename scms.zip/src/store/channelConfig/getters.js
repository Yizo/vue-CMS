/**
 * Created by isec on 2017/4/14.
 */

export default {
  channelData: function (state) {
    return state.channelData;
  },
  addChannelItem:function(state){
    return state.addChannelItem
  },
  saveChannelSave:function(state){
    return state.saveChannelSuccess;
  },
}
