/**
 * Created by admin on 2017/3/28.
 */
export default {

  ACTIVEDAY_day_data:(state) => state.day_data,
  ACTIVEDAY_day_details_data:(state) => state.day_details_data,
  ACTIVEDAY_month_data:(state) => state.month_data,
  ACTIVEDAY_month_details_data:(state) => state.month_details_data,
}
