/**
 * Created by admin on 2017/3/28.
 */
export default {
  //获取用户列表信息
  USERINFO_base:function(state){
    return state.base
  }
}
