/**
 * Created by admin on 2017/3/28.
 */
/*获取用户基础信息*/
export const USERINFO_GETUSERS = 'USERINFO_GETUSERS';

