/**
 * Created by isec on 2017/4/15.
 */


//获取动态Ip数据
export const GET_DNCIP_DATA = 'GET_DNCIP_DATA';

//添加动态ip数据
export const ADD_DNCIP_ITEM = 'ADD_DNCIP_ITEM';

//删除动态IP数据
export const DELETE_DNCIP_ITEM = 'DELETE_DNCIP_ITEM';

//更新动态IP数据
export const UPDATE_DNCIP_ITEM = 'UPDATE_DNCIP_ITEM';

//获取人数详情
export const GET_PERSON_DETAILS = 'GET_PERSON_DETAILS';

//获取区域人数连接人数详情
export const GET_REGION_DETAILS = 'GET_REGION_DETAILS';

//
export const GET_REGION_lINE_DETAILS = 'GET_REGION_lINE_DETAILS';
