/**
 * Created by isec on 2017/4/15.
 */

export default {
  dcpIpData(state){
    return state.dncIpData;
  },
  personDetails(state){
    return state.personDetails;
  },
  regionDetails(state){
    return state.regionDetails;
  },
  regionLineDetails(state){
    return state.regionLineDetails;
  }
}
