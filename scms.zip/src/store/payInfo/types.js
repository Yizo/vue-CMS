/**
 * Created by admin on 2017/3/28.
 */

export const SETTIME = 'SETTIME';
/*付费信息*/
export const FFINFO = 'FFINFO';

export const PAYDETAILS = 'PAYDETAILS';

export const CONSUMECOINS = 'CONSUMECOINS';

