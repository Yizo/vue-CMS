/**
 * Created by admin on 2017/3/28.
 */
export default {

  time:(state) => state.time,
  ff_data:(state) => state.ff_data,
  pay_details_data:(state) => state.pay_details_data,
  summary_data:(state) => state.summary_data.data,
}
