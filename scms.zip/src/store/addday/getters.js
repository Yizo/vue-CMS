/**
 * Created by admin on 2017/3/28.
 */
export default {

  day_data:(state) => state.day_data,
  day_details_data:(state) => state.day_details_data,
  month_data:(state) => state.month_data,
  month_details_data:(state) => state.month_details_data,
}
