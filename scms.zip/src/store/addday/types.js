/**
 * Created by admin on 2017/3/28.
 */

export const ADDDAY_DAY = 'ADDDAY_DAY';

export const ADDDAY_DAY_DETAILS = 'ADDDAY_DAY_DETAILS';

export const ADDDAY_MONTH = 'ADDDAY_MONTH';

export const ADDDAY_MONTH_DETAILS = 'ADDDAY_MONTH_DETAILS';

