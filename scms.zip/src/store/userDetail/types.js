/**
 * Created by admin on 2017/3/28.
 */

/*账号详情-基础信息*/
export const u_base_info = 'u_base_info'
/*账号详情-连接请求*/
export const u_connection_logs = 'u_connection_logs'
/*账号详情-关联设备*/
export const u_devices = 'u_devices'
/*账号详情-操作路径*/
export const u_operation_logs = 'u_operation_logs'
/*账号详情-用户去向*/
export const u_access_logs = 'u_access_logs'
/*账号详情-充值信息*/
export const u_transaction_logs = 'u_transaction_logs'
/*账号详情-信息管理*/
export const u_profile = 'u_profile'

