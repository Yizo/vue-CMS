/**
 * Created by admin on 2017/3/28.
 */
import * as type from './types.js';

export default {
  SETID:(state,parm)=>state.id = parm,
  /*账号详情-基础信息*/
  [type.u_base_info]:(state,parm) => state.UD_base_info = parm ,
  /*账号详情-连接请求*/
  [type.u_connection_logs]:(state,parm) => state.UD_connection_logs = parm ,
  /*账号详情-关联设备*/
  [type.u_devices]:(state,parm) => state.UD_devices = parm ,
  /*账号详情-操作路径*/
  [type.u_operation_logs]:(state,parm) => state.UD_operation_logs = parm ,
  /*账号详情-用户去向*/
  [type.u_access_logs]:(state,parm) => state.UD_access_logs = parm ,
  /*账号详情-充值信息*/
  [type.u_transaction_logs]:(state,parm) => state.UD_transaction_logs = parm ,
  /*账号详情-信息管理*/
  [type.u_profile]:(state,parm) => state.UD_profile = parm ,
}
