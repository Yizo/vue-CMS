/**
 * Created by admin on 2017/3/28.
 */
/*登录*/
export const LOGIN_LOGIN = 'LOGIN_LOGIN';
/*登录请求是否成功*/
export const LOGIN_ISLOGINREQUEST = 'LOGIN_ISLOGINREQUEST';
